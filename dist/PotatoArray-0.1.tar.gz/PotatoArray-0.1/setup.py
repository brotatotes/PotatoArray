from setuptools import setup

setup(
	name = 'PotatoArray',
	version = '0.1',
	scripts = ['PotatoArray.py'],
	author = 'Eric Hao',
	author_email = 'erichao2018@gmail.com',
	description = ("Arrays start at 2."),
	url = "https://github.com/brotatotes/PotatoArray"
)
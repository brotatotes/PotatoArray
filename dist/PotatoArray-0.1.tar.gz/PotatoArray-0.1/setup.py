from setuptools import setup

setup(
	name = 'PotatoArray',
	version = '0.1',
	scripts = ['PotatoArray.py']
)